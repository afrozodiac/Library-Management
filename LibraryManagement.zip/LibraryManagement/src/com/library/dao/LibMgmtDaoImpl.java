package com.library.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.library.db.DBConn;
import com.library.entity.User;
import com.library.entity.Book;

public class LibMgmtDaoImpl {
	public String UserAuth(User user) throws SQLException, ClassNotFoundException {
		Connection conn = null;
		try {
			conn = DBConn.connect();
			String sql = "SELECT id,password FROM user where id=? and password=?";
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, user.getId());
			ps.setString(2, user.getPassword());
		    ResultSet rs = ps.executeQuery();
		    while(rs.next()){
		    	String first = rs.getString("id");
		        String last = rs.getString("password");
		        return first;
		     }

		} catch (SQLException e) {
			System.out.println("Connection Failed! Check output console");
			e.printStackTrace();
			return "excep";
		}
		return "na";
	}
	
	public List<Book> showBook(){
		Connection conn = null;
		try {
			conn = DBConn.connect();
			String sql = "SELECT * FROM book";
			Statement st = conn.createStatement();
		    ResultSet rs = st.executeQuery(sql);
		    List<Book> books = new ArrayList<Book>();
		    while(rs.next()){
		    	Book book = new Book();
		    	book.setBookId(rs.getInt("BookId"));
		    	book.setBookName(rs.getString("BookName"));
		    	book.setPrice(rs.getInt("Price"));
		    	book.setCopies(rs.getInt("Copies"));
		    	book.setAvailable(rs.getInt("available"));
		    	books.add(book);
		     }
			return books;
		}catch(SQLException sql)
		{
			
		}
		return null;
	}
}
