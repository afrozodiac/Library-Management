package com.library.entity;

import java.sql.Date;

public class transaction {
	private int id;
	private int BookId;
	private String IssuedTo;
	private Date StartDate;
	private Date EndDate;
	private int type;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getBookId() {
		return BookId;
	}
	public void setBookId(int bookId) {
		BookId = bookId;
	}
	public String getIssuedTo() {
		return IssuedTo;
	}
	public void setIssuedTo(String issuedTo) {
		IssuedTo = issuedTo;
	}
	public Date getStartDate() {
		return StartDate;
	}
	public void setStartDate(Date startDate) {
		StartDate = startDate;
	}
	public Date getEndDate() {
		return EndDate;
	}
	public void setEndDate(Date endDate) {
		EndDate = endDate;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	
	
}
