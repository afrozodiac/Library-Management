package com.library.service;

public interface LibMgmtService {

}
