package com.library.service;

import java.sql.SQLException;
import java.util.List;

import com.library.dao.LibMgmtDaoImpl;
import com.library.entity.Book;
import com.library.entity.User;

public class LibMgmtServiceImpl {
	LibMgmtDaoImpl Dao = new LibMgmtDaoImpl();
	public String login(User user) throws SQLException, ClassNotFoundException {
		return Dao.UserAuth(user);
		}
	public List<Book> showBook() {
		return Dao.showBook();
	}

}
