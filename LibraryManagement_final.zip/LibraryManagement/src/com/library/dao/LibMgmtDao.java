package com.library.dao;

public interface LibMgmtDao {

}
