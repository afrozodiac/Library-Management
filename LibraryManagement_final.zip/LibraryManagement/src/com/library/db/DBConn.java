package com.library.db;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;

public class DBConn {
	public static Connection connect() {
	Connection conn = null;
	try {
		Class.forName("com.mysql.jdbc.Driver");
	} catch (ClassNotFoundException e) {
		
	}
	try {
		conn = DriverManager.getConnection("jdbc:mysql://den1.mysql2.gear.host:3306/virusdata","virusdata", "Um6IZlqb5??T");
	} catch (SQLException e) {
	}
	return conn;
	}
}